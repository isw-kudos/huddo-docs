## Deploying Apps in Portainer

1. Create GCloud Servers

2. SSH to each server to trust IP
   `ssh -i /home/awelch/.ssh/google_compute_engine 35.211.3.188`

3. Update hosts config IPs

4. Setup servers with docker-swarm, Portainer & Traefik  
   `cd /devops/docker-swarm/ansible`  
   `ansible-playbook -i hosts/gcloud.yml deploy.yml -v`

5. Create admin user in Portainer  
   Open Dashboard as defined in `{{dashboard_host}}`  
   ie `https://swarm.isw.net.au`

6. Add Dockerhub auth  
   Open `Registries`  
   Tick `Authentication`  
   add `Username, Password`

7. Deploy App Stacks (& optional logging stack)
   Open `Stacks`  
   `Add Stack`
   Name, docker-compose YAML

8. Updated DNS record to point App to `{{dashboard_host}}`  
   ie `staging.kudosboards.com` -> `swarm.isw.net.au`  
   `staging-api.kudosboards.com` -> `swarm.isw.net.au`  
   `kibana-staging.kudosboards.com` -> `swarm.isw.net.au`

9. Configure Kibana logs
   login to kibana, ie `https://kibana-staging.kudosboards.com`  
   create index on `logspout*`  
   create search, open discover, select `docker.name` + `message` fields  
   save
