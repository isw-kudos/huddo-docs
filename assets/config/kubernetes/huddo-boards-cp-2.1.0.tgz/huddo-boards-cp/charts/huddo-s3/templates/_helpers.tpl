{{- define "huddo-s3.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride -}}
{{- else -}}
{{- printf "%s-s3" .Release.Name -}}
{{- end -}}
{{- end -}}
