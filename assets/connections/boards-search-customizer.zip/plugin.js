/* eslint-disable prefer-arrow-callback */
/* eslint-disable no-extend-native */
/* eslint-disable prefer-rest-params */
/* eslint-disable object-shorthand */
/* eslint-disable no-script-url */
/* eslint-disable no-var */

// ==UserScript==
// @name         Kudos Boards Search Customizer
// @namespace    https://kudosboards.com
// @version      1.0
// @description  Kudos Boards Search Customizer for HCL Connections
// @author       Kudos Boards
// @match        https://[YOUR_CONNECTIONS_HOST]/*
// @grant        none
// ==/UserScript==

(function() {
  "use strict";
  // polyfills
  if (!Array.prototype.includes) {
    Array.prototype.includes = function(search) {
      return !!~this.indexOf(search);
    };
  }

  const baseUrl = window.location.origin;
  // NOTE: replace targetOrigin with your connections host if you want to restrict messages to only boards and your connections environment
  const targetOrigin = "";

  function debounce(func, wait, immediate) {
    let timeout;
    return function() {
      const context = this,
        args = arguments;
      const later = function() {
        timeout = null;
        if (!immediate) func.apply(context, args);
      };
      const callNow = immediate && !timeout;
      clearTimeout(timeout);
      timeout = setTimeout(later, wait);
      if (callNow) func.apply(context, args);
    };
  }

  if (typeof dojo != "undefined") {
    require([
      "dojo/query",
      "dojo/io-query",
      "dijit/registry",
      "dojo/dom-attr",
      "dojo/domReady!"
    ], function(query, ioQuery, registry, domAtrr) {
      const getIframe = function(panel) {
        return panel
          ? query("iframe#lconn_search_searchPanel_kudos_widget")[0]
          : query("iframe#lconnKudosContainer")[0];
      };

      const getSearchURL = function(value, ps, panel) {
        let url =
          baseUrl + "/boards/app/search/connections?nav=false&search=" + value;
        if (ps) url += "&ps=" + ps;
        if (panel) url += "&panel=true";
        return url;
      };

      const sendStyles = function(panel) {
        const iframe = getIframe(panel);
        const styleUrls = [];
        const styles = query('link[rel="stylesheet"]');
        const html = query("html")[0];
        const body = query("body")[0];
        styles.forEach(function(s) {
          styleUrls.push(s.href);
        });
        iframe.contentWindow.postMessage(
          {
            styleUrls: styleUrls,
            htmlClasses: html.className,
            bodyClasses: body.className
          },
          targetOrigin || "*"
        );
      };

      const setLoading = function(loaded) {
        let loading = query("center#kudos-loading")[0];
        if (!loading) {
          loading = document.createElement("center");
          loading.id = "kudos-loading";
          const loadingImg = document.createElement("div");
          loadingImg.className = "lotusLoading";
          loading.style.display = loaded ? "none" : "block";
          loading.appendChild(loadingImg);
          loading.style.display = loaded ? "none" : "block";
        }
        loading.style.display = loaded ? "none" : "block";
        return loading;
      };

      const iframeOnload = function(panel) {
        sendStyles(panel);
        if (!panel) setLoading(true);
        window.addEventListener("message", function(e) {
          if (!targetOrigin || e.origin === "targetOrigin") {
            if (e.data.height) {
              const iframe = getIframe(panel);
              iframe.style.height = "";
              iframe.style.height = e.data.height + "px";
            } else if (e.data.getStyles) {
              sendStyles(panel);
            }
          }
        });
      };

      const createIframe = function(panel) {
        const iframe = document.createElement("iframe");
        iframe.name = "kudos-boards-search";
        iframe.scrolling = "no";
        iframe.marginwidth = "0";
        iframe.marginheight = "0";
        iframe.frameborder = "0";
        iframe.vspace = "0";
        iframe.hspace = "0";
        iframe.addEventListener("load", function() {
          iframeOnload(panel);
        });
        return iframe;
      };

      let showIframe = false;
      let onlyIframe = false;

      const createSearchOption = function() {
        const searchFilter = query("ul.searchFilter")[0];
        if (searchFilter) {
          const searchFilterWidget = registry.getEnclosingWidget(searchFilter);
          const newSearchOption = document.createElement("li");
          newSearchOption.className = "lconnSearchComponentFilter-kudos_boards";
          const newSearchOptionDiv = document.createElement("div");
          const newSearchOptionLink = document.createElement("a");
          newSearchOptionLink.role = "button";
          newSearchOptionLink.href = "javascript:;";
          newSearchOptionLink.accesskey = "K";
          newSearchOptionLink.tabindex = "-1";
          newSearchOptionLink.textContent = "Activities/Boards";
          newSearchOptionLink.onclick = function() {
            searchFilterWidget.onSelect("kudos_boards");
            newSearchOption.className += " lotusSelected searchFilterSelected";
            const childNodes = Array.prototype.slice.call(
              searchFilter.childNodes
            );
            childNodes.forEach(function(c) {
              c.firstChild.firstChild.title =
                "Show results from Activities/Boards";
            });
          };
          if (onlyIframe) {
            newSearchOptionLink.onclick();
          }
          newSearchOptionDiv.appendChild(newSearchOptionLink);
          newSearchOption.appendChild(newSearchOptionDiv);
          searchFilter.insertBefore(
            newSearchOption,
            searchFilter.firstChild.nextSibling
          );
        }
      };

      const checkScope = function() {
        const url = ioQuery.queryToObject(
          decodeURIComponent(window.location.hash).substr(1)
        );
        showIframe = true;
        onlyIframe = false;
        for (var key in url) {
          if (key === "scope") {
            if (!["allconnections", "kudos_boards"].includes(url[key])) {
              showIframe = false;
            } else if (url[key] === "kudos_boards") {
              onlyIframe = true;
            }
          }
        }
      };

      const addPanelIframe = function() {
        const searchPanelResults = query(
          "div#lconn_search_searchPanel_typeahead_TypeaheadWidget_0"
        )[0];
        const search =
          query("input#dijit_form_TextBox_2")[0] ||
          query("input#dijit_form_TextBox_1")[0];

        if (searchPanelResults) {
          let iframe = query("iframe#lconn_search_searchPanel_kudos_widget")[0];
          if (iframe) {
            iframe.src = getSearchURL(search.value, 5, true);
          } else {
            iframe = createIframe(true);
            iframe.className = "pfDirectoryResults lconnSearchHighlight";
            iframe.id = "lconn_search_searchPanel_kudos_widget";
            iframe.src = getSearchURL(search.value, 5, true);
            iframe.style.height = "100%";
            iframe.style.minHeight = "350px";
            iframe.style.width = "400px";
            iframe.style.border = "none";
            iframe.style.top = "40px";
            searchPanelResults.appendChild(iframe);
          }
          const changeSrc = debounce(function(e) {
            iframe.src = getSearchURL(search.value, 5, true);
          }, 250);
          search.addEventListener("input", changeSrc);
        }
      };

      const addMainIframe = function() {
        if (showIframe) {
          const searchContainer = query("div#contentContainer_results")[0];
          const searchContent = query("div#contentContainer_results_View")[0];
          const search = query(
            "input[name=lconn_search_QueryForm_0_textBox_textbox]"
          )[0];
          if (searchContainer && searchContent) {
            let iframe = query("iframe#lconnKudosContainer")[0];
            if (iframe) {
              iframe.src = getSearchURL(search.value, 3);
              setLoading(false);
            } else {
              iframe = createIframe();
              iframe.id = "lconnKudosContainer";
              iframe.src = getSearchURL(search.value);
              iframe.style.height = "0px";
              iframe.style.minHeight = "350px";
              iframe.style.width = "100%";
              iframe.style.border = "none";
              if (onlyIframe) {
                iframe.src = getSearchURL(search.value);
                searchContent.parentNode.replaceChild(
                  document.createElement("span"),
                  searchContent.nextSibling
                );
                searchContent.parentNode.replaceChild(iframe, searchContent);
                searchContainer.insertBefore(setLoading(false), iframe);
              } else {
                const boardsDiv = document.createElement("div");
                boardsDiv.style.width = "32%";
                boardsDiv.style.display = "inline-block";
                boardsDiv.style.verticalAlign = "top";
                boardsDiv.style.marginLeft = "1%";
                boardsDiv.style.marginTop = "15px";
                boardsDiv.style.minWidth = "375px";
                searchContent.style.width = "67%";
                searchContent.style.maxWidth = "calc(99% - 375px)";
                searchContent.style.display = "inline-block";
                boardsDiv.appendChild(setLoading(false));
                boardsDiv.appendChild(iframe);
                searchContainer.insertBefore(
                  boardsDiv,
                  searchContent.nextSibling
                );
              }

              const checkSearch = new MutationObserver(function(e) {
                addMainIframe();
              });
              checkSearch.observe(searchContent, { childList: true });
            }
          }
        }
      };

      const searchButton = query("div.icSearchBarButtons")[0];
      if (searchButton) {
        searchButton.addEventListener("click", function() {
          addMainIframe();
        });
      }

      window.onload = function() {
        checkScope();
        createSearchOption();
        addMainIframe();
        addPanelIframe();
      };
      window.onhashchange = function() {
        checkScope();
        addMainIframe();
      };
    });
  }
})();
