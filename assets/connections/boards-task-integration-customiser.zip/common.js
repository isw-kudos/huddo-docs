/* eslint-disable */

let boardsIntegrationslogging = false;
let boardsIntegrationURL = "https://boards.huddo.com";
let boardsButtonTitle = "Tasks";

if(boardsIntegrationslogging)
    console.info('Boards Integrations Customiser - common');

let boardsShareButtonContainer = "#headerSharebox";

let boardsPrimaryLink = window.location.href;
let boardsCardTitle = "New Card";
let boardsNumTasks = 0;

function boardsGetPageDetails()
{
	boardsPrimaryLink = window.location.href;
		
    boardsCardTitle = document.title;

    if(boardsPrimaryLink.includes('/forums'))
    {
        boardsPrimaryLink = window.location.origin + window.location.pathname + '?id=' + dojo.query('#forMetrics')[0].getAttribute('contentid');
    }
    else if(boardsPrimaryLink.includes('/profiles'))
    {
        boardsPrimaryLink = window.location.origin + window.location.pathname + '?key=' + dojo.query('#profileKey')[0].getAttribute('value');
    }

    if(boardsIntegrationslogging)
    {
        console.info('Boards Integrations Customiser - getPageDetails');
        console.info('Boards Card Title: ' + boardsCardTitle);
        console.info('Boards Primary Link: ' + boardsPrimaryLink);
    }

    let linkedCardsURL = boardsIntegrationURL + '/app/linkedcards?title=' + encodeURIComponent(boardsCardTitle) + '&url=' + encodeURIComponent(boardsPrimaryLink);
    
    dojo.byId('boardsLinkedCardiFrame').src = linkedCardsURL;
}

function boardsCommonShowDialog() {
	if(boardsIntegrationslogging)
		console.log('Boards Integrations Customiser - boardsCommonShowDialog');

    dojo.byId('boards-related-content').style.display = 'block';
    document.body.style.overflowY = 'hidden';
    
}

function boardsCommonHideDialog() {
	if(boardsIntegrationslogging)
		console.log('Boards Integrations Customiser - boardsCommonHideDialog');
    
    dojo.byId('boards-related-content').style.display = 'none';
    document.body.style.overflowY = 'auto';
}


let boardsCommonPopstate = function(event) {
    boardsGetPageDetails();
}

window.addEventListener("popstate", boardsCommonPopstate);

window.addEventListener("message", (event) => {
	
    if(event.origin !== boardsIntegrationURL)
        return;

    if(boardsIntegrationslogging)
		console.log('Boards Integrations Customiser - message');

	let eventData = event.data;
	
	//huddo-task-count=0
    if(typeof eventData === "string" && eventData.includes("huddo-task-count"))
    {
        boardsNumTasks = event.data.split('=')[1];
		
		if(boardsIntegrationslogging)
		{
			console.log('Boards Integrations Customiser - eventData',eventData);
			console.log('Boards Integrations Customiser - numTasks',boardsNumTasks);
		}
		
        if(window.location.href.includes("file"))
        {
            dojo.byId('huddoBoardsFilesCardCount').innerHTML = boardsNumTasks;
            
            if(boardsNumTasks > 0)
            {
                dojo.byId('huddoBoardsFilesCardCount').style.display = 'block';
                dojo.byId('huddoBoardsFilesCardCount').style.opacity = '1';
            }
            else
            {
                dojo.byId('huddoBoardsFilesCardCount').style.display = 'none';
                dojo.byId('huddoBoardsFilesCardCount').style.opacity = '0';
            }
        }
        else
        {
            dojo.byId('huddoBoardsCardCount').innerHTML = boardsNumTasks;
            
            if(boardsNumTasks > 0)
            {
                dojo.byId('huddoBoardsCardCount').style.display = 'block';
                dojo.byId('huddoBoardsCardCount').style.opacity = '1';
            }
            else
            {
                dojo.byId('huddoBoardsCardCount').style.display = 'none';
                dojo.byId('huddoBoardsCardCount').style.opacity = '0';
            }
        }
    }
},false);

function boardsCommonLoadCode() { 

    waitQuery = boardsShareButtonContainer;

    if(typeof(dojo) != "undefined") {
        require(["dojo/domReady!"], function(){
            try {
                // utility function to let us wait for a specific element of the page to load...
                var waitFor = function(callback, elXpath, elXpathRoot, maxInter, waitTime) {
                    if(!elXpathRoot) var elXpathRoot = dojo.body();
                    if(!maxInter) var maxInter = 10000;  // number of intervals before expiring
                    if(!waitTime) var waitTime = 1;  // 1000=1 second
                    if(!elXpath) return;
                    var waitInter = 0;  // current interval
                    var intId = setInterval( function(){
                        if( ++waitInter<maxInter && !dojo.query(elXpath,elXpathRoot).length) return;

                        if( waitInter >= maxInter) { 
                            clearInterval(intId);
                            if(boardsIntegrationslogging)
                                console.log("**** WAITFOR ["+elXpath+"] WATCH EXPIRED!!! interval "+waitInter+" (max:"+maxInter+")");
                        } else {
                            if(boardsIntegrationslogging)
                                console.log("**** WAITFOR ["+elXpath+"] WATCH TRIPPED AT interval "+waitInter+" (max:"+maxInter+")");
                            clearInterval(intId);
                            callback();
                        }
                    }, waitTime);
                };

                // here we use waitFor to wait on the .lotusStreamTopLoading div.loaderMain.lotusHidden element
                // before we proceed to customize the page...
                waitFor( function(){
                // wait until the "loading..." node has been hidden
                // indicating that we have loaded content.
                
                dojo.place("<li class=\"shareboxLi\" id=\"huddoBoardsCreateIcon\" onmouseenter=\"boardsCommonShowDialog()\" onmouseleave=\"boardsCommonHideDialog()\" >" + 
                                "<a class=\"lotusBannerBtn\" role=\"button\" title=\"" + boardsButtonTitle + "\" target=\"popup\">" + boardsButtonTitle +
		   		                "</a>" + 
                                "<div id=\"huddoBoardsCardCount\" style=\"opacity: 0;position: relative; width:15px; margin-left:55px; margin-top:5px; text-align:center;\" class=\"icBanner-badge  icBanner-badge-onprem\">" + boardsNumTasks +
                                "</div>" + 
                                "<div style='display:none; position:fixed; margin-left: -323px; background:white; border:1px solid;' id='boards-related-content' class='boards-dropdown-content'>" + 
                                    "<iframe id='boardsLinkedCardiFrame' frameBorder=\"0\" title=\"Huddo Boards Related Cards\" src=\"about:blank\" height=\"550\" width=\"400\" sandbox=\"allow-same-origin allow-scripts allow-popups allow-forms allow-modals\"></iframe>" + 
                                "</div>" + 
                            "</li>",dojo.query(boardsShareButtonContainer)[0],'after');


            boardsGetPageDetails();

                        },
                waitQuery);
        } catch(e) {
            alert("Exception occurred in Huddo Boards Files Customiser: " + e);
        }
    });
    }
}

boardsCommonLoadCode();