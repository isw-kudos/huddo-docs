/* eslint-disable */
if(boardsIntegrationslogging)
    console.log('Boards Customiser - Files');

let boardsFilesButtonContainer = ".ics-viewer-action-upload";
let boardsFilesPrimaryLink = window.location.href;

function boardsFilesShowDialog() {
	if(boardsIntegrationslogging)
		console.log('Boards Integrations Customiser - boardsFilesShowDialog');

    dojo.byId('boards-related-files-content').style.display = 'block';
    document.body.style.overflowY = 'hidden';
    
}

function boardsFilesHideDialog() {
	if(boardsIntegrationslogging)
		console.log('Boards Integrations Customiser - boardsFilesHideDialog');
    
    dojo.byId('boards-related-files-content').style.display = 'none';
    document.body.style.overflowY = 'auto';
}

function boardsFilesLoadCode() { 

    boardsFilesPrimaryLink = window.location.href;
    waitQuery = boardsFilesButtonContainer;

    if(typeof(dojo) != "undefined") {
        require(["dojo/domReady!"], function(){
            try {
                // utility function to let us wait for a specific element of the page to load...
                var waitFor = function(callback, elXpath, elXpathRoot, maxInter, waitTime) {
                    if(!elXpathRoot) var elXpathRoot = dojo.body();
                    if(!maxInter) var maxInter = 10000;  // number of intervals before expiring
                    if(!waitTime) var waitTime = 1;  // 1000=1 second
                    if(!elXpath) return;
                    var waitInter = 0;  // current interval
                    var intId = setInterval( function(){
                        if( ++waitInter<maxInter && !dojo.query(elXpath,elXpathRoot).length) return;

                        if( waitInter >= maxInter) { 
                            clearInterval(intId);
                            if(boardsIntegrationslogging)
                                console.log("**** WAITFOR ["+elXpath+"] WATCH EXPIRED!!! interval "+waitInter+" (max:"+maxInter+")");
                        } else {
                            if(boardsIntegrationslogging)
                                console.log("**** WAITFOR ["+elXpath+"] WATCH TRIPPED AT interval "+waitInter+" (max:"+maxInter+")");
                            if(dojo.byId("huddoBoardsCreateFilesIcon") === null)
                            {
                                clearInterval(intId);
                                callback();
                            }
                        }
                    }, waitTime);
                };

                // here we use waitFor to wait on the .lotusStreamTopLoading div.loaderMain.lotusHidden element
                // before we proceed to customize the page...
                waitFor( function(){
                // wait until the "loading..." node has been hidden
                // indicating that we have loaded content.
                if(boardsFilesPrimaryLink.includes("file"))
                {
                    dojo.place("<li class=\"ics-viewer-action\" id=\"huddoBoardsCreateFilesIcon\" onmouseenter=\"boardsFilesShowDialog()\" onmouseleave=\"boardsFilesHideDialog()\" >" + 
                                    "<a class=\"lotusBannerBtn\" role=\"button\" title=\"" + boardsButtonTitle + "\" target=\"popup\">" + boardsButtonTitle +
		   		                    "</a>" + 
                                    "<div id=\"huddoBoardsFilesCardCount\" style=\"opacity: 0;position: relative; width:15px; margin-left:20px; margin-top:5px; text-align:center;\" class=\"icBanner-badge  icBanner-badge-onprem\">" + boardsNumTasks +
                                    "</div>" + 
                                    "<div style='display:none; position:fixed; margin-left: -323px; margin-top:-18px; background:white; border:1px solid; z-index:10000;' id='boards-related-files-content' class='boards-dropdown-content'>" + 
                                        "<iframe id='boardsLinkedCardFilesiFrame' frameBorder=\"0\" title=\"Huddo Boards Related Cards\" src=\"about:blank\" height=\"550\" width=\"400\"></iframe>" + 
                                    "</div>" + 
                                "</li>",dojo.query(boardsFilesButtonContainer)[0],'before');

                    boardsFileCardTitle = document.title;
                    let linkedCardsURL = boardsIntegrationURL + '/app/linkedcards?title=' + encodeURIComponent(boardsFileCardTitle) + '&url=' + encodeURIComponent(boardsFilesPrimaryLink);
                    dojo.byId('boardsLinkedCardFilesiFrame').src = linkedCardsURL;
                }
                        },
                waitQuery);
        } catch(e) {
            alert("Exception occurred in Huddo Boards Files Customiser: " + e);
        }
    });
    }
}

setInterval(function () 
{
    if( boardsFilesPrimaryLink !== window.location.href) {

        if(boardsIntegrationslogging)
            console.log('Files link changed');

        boardsFilesPrimaryLink = window.location.href
        boardsFilesLoadCode();
    }
}, 10);

boardsFilesLoadCode();